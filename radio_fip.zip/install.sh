#!/bin/bash

set -e

echo "Installing radio_fip dependencies"

cd "$(dirname "$0")"

if [ -f package.json ]; then
    npm install --omit=dev
fi

if [ ! -d "node_modules/v-conf" ]; then
    echo "ERROR: dependency v-conf installation failed"
    exit 1
fi

if [ ! -d "node_modules/fs-extra" ]; then
    echo "ERROR: dependency fs-extra installation failed"
    exit 1
fi

echo "radio_fip dependencies installed"

echo "plugininstallend"
#!/bin/bash
set -e

echo "Installing radio_fip dependencies"

cd "$(dirname "$0")"

if [ ! -f package.json ]; then
    echo "ERROR: package.json not found"
    exit 1
fi

npm install --omit=dev
chown -R volumio:volumio .

echo "INSTALL CHECK:"

for dep in v-conf fs-extra kew; do
    if [ ! -d "node_modules/$dep" ]; then
        echo "ERROR: dependency $dep installation failed"
        exit 1
    fi
done

sync

echo "radio_fip dependencies installed"

echo "plugininstallend"
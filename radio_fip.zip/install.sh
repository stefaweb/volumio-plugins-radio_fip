#!/bin/bash
set -e

echo "Installing radio_fip dependencies"

cd "$(dirname "$0")"

if [ ! -f package.json ]; then
    echo "ERROR: package.json not found"
    exit 1
fi

rm -rf node_modules package-lock.json

npm install --omit=dev

echo "INSTALL CHECK:"
ls -la node_modules

for dep in v-conf fs-extra; do
    if [ ! -d "node_modules/$dep" ]; then
        echo "ERROR: dependency $dep installation failed"
        exit 1
    fi
done

echo "INSTALL CHECK:"
pwd
ls -la
ls -la node_modules
ls -la node_modules/kew || true

echo "radio_fip dependencies installed"

echo "plugininstallend"
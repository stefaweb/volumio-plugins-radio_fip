#!/bin/bash
set -e
echo "Installing radio_fip dependencies"
cd "$(dirname "$0")"
if [ ! -f package.json ]; then
    echo "ERROR: package.json not found"
    exit 1
fi
npm install --omit=dev
if [ ! -d "node_modules/v-conf" ]; then
    echo "ERROR: dependency v-conf installation failed"
    exit 1
fi
if [ ! -d "node_modules/fs-extra" ]; then
    echo "ERROR: dependency fs-extra installation failed"
    exit 1
fi
if [ ! -d "node_modules/kew" ]; then
    echo "ERROR: dependency kew installation failed"
    exit 1
fi
echo "radio_fip dependencies installed"
echo "plugininstallend"
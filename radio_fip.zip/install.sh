#!/bin/bash

set -e

echo "Installing radio_fip dependencies"

cd "$(dirname "$0")"

for dep in v-conf fs-extra kew; do
    if [ ! -d "node_modules/$dep" ]; then
        echo "ERROR: dependency $dep installation failed"
        exit 1
    fi
done

echo "radio_fip dependencies installed"

echo "plugininstallend"